#ifndef __MAIN_H
#define __MAIN_H

extern uint8_t UsartRecvOk;
extern uint8_t SenBufLen;
extern uint8_t RcvBufLen;
extern UART_HandleTypeDef UART_HandleStruct;

#endif
